from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

model = joblib.load('Email_spam_detection_model.joblib')
vectorizer = joblib.load('tfidf_vectorizer.joblib')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    message = request.form['message']
    vectorized = vectorizer.transform([message])
    prediction = model.predict(vectorized)[0]
    label = 'Not Spam ✅' if prediction == 1 else 'Spam ❌'
    return render_template('index.html', prediction=label, message=message)

if __name__ == '__main__':
    app.run(debug=True)
